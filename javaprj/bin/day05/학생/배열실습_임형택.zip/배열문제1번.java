package day05;

public class 배열문제1번 {

	public static void main(String[] args) {
		
		String [] menu = {"짜장면","탕수육","짬뽕","잡채밥","볶음밥"};
		
		System.out.println("점심 메뉴 추천");
		for(int i=0; i<menu.length; i++) {
			System.out.println(menu[i]);
		}
		
	}

}
