package day08;

public class School {
	String name;
	String type;
	String address;
}
