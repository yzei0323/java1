package day12.상속.super사용;

public class BMain {

	public static void main(String[] args) {
		 
		
		
		B b = new B();
		
		b.실행하기();

	}

}
