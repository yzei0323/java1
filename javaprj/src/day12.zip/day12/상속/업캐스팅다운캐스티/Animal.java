package day12.상속.업캐스팅다운캐스티;

public class Animal {
	
	public void  짖다() {
		System.out.println("짖다");
	}

}
