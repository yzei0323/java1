package day12.상속.상속사용;

public class StudentWorker  extends Student{

	public void 일하기() {
		System.out.println("일하기");
	}
}
