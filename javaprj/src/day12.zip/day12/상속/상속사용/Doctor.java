package day12.상속.상속사용;

public class Doctor extends Researcher  {
	public void 발표() {
		System.out.println("연구발표하기");
	}
}
