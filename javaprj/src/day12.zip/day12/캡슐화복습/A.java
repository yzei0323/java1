package day12.캡슐화복습;

public class A {
	
	public static void 매서드1() {
		
	}
	
	/* 클래스를 실행하는 방법 ( 매서드  ), 함수 =>  main매서드(약속된 매서드)  */
	public static void main( String[] args) {
		
	}

}


// A클래스가 제공하는 기능 
// A클래스를 사용하는 방법